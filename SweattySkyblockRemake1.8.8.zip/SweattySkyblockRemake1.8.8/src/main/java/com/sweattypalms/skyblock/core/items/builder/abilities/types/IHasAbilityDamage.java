package com.sweattypalms.skyblock.core.items.builder.abilities.types;

public interface IHasAbilityDamage {
    double getBaseAbilityDamage();
    double getAbilityScaling();
}
