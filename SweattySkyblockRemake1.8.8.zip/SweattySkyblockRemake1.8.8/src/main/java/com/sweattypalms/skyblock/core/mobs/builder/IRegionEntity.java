package com.sweattypalms.skyblock.core.mobs.builder;

import com.sweattypalms.skyblock.core.regions.Regions;

public interface IRegionEntity {
    Regions getRegion();
}
