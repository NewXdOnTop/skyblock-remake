package com.sweattypalms.skyblock.core.enchants.builder;

public interface UltimateEnchantment {}
