package com.sweattypalms.skyblock.core.items.builder.reforges;

import java.util.List;

public interface IAdvancedReforge {
    List<String> getLore();
}
