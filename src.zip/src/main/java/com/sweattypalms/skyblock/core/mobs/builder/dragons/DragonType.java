package com.sweattypalms.skyblock.core.mobs.builder.dragons;

public enum DragonType {
    SUPERIOR,
    STRONG,
    UNSTABLE,
    WISE,
    OLD,
    PROTECTOR,
    YOUNG,
}
